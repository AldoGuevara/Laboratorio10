﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Ingrese la longitud del cateto A en metros: ");
            double catetoA = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese la amplitud del ángulo opuesto al cateto A en grados: ");
            double anguloOpuestoA = Convert.ToDouble(Console.ReadLine());

            TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

            Console.WriteLine("Datos del Triángulo Rectángulo:");
            Console.WriteLine($"Cateto A: {objTriangulo.ObtenerCatetoA()} metros");
            Console.WriteLine($"Cateto B: {objTriangulo.ObtenerCatetoB()} metros");
            Console.WriteLine($"Hipotenusa: {objTriangulo.ObtenerHipotenusa()} metros");
            Console.WriteLine($"Ángulo Opuesto a A: {objTriangulo.ObtenerAnguloOpuestoA()} grados");
            Console.WriteLine($"Ángulo Opuesto a B: {objTriangulo.ObtenerAnguloOpuestoB()} grados");
            Console.WriteLine($"Área: {objTriangulo.ObtenerArea()} metros cuadrados");

            Console.ReadKey();
        }

        

    }
    }

